const CS = (() => {
const KEY={products:"csbooks-products-v2",promos:"csbooks-promos-v2",cart:"csbooks-cart-v2",users:"csbooks-users-v2",current:"csbooks-current-v2",orders:"csbooks-orders-v2"};
const starterProducts=[
{id:1,title:"คืนที่ดาวเต็มฟ้า",author:"ณิชาภา",category:"โรแมนติก",price:289,stock:20,image:"https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=600&q=80",isNew:true,active:true},
{id:2,title:"อาณาจักรแห่งเงา",author:"กฤติน",category:"แฟนตาซี",price:350,stock:15,image:"https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80",isNew:true,active:true},
{id:3,title:"คดีปริศนาห้องหมายเลข 9",author:"พิมพ์ชนก",category:"สืบสวน",price:319,stock:12,image:"https://images.unsplash.com/photo-1519682337058-a94d519337bc?auto=format&fit=crop&w=600&q=80",isNew:false,active:true},
{id:4,title:"ฤดูร้อนของความทรงจำ",author:"มินตรา",category:"วรรณกรรม",price:259,stock:18,image:"https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&w=600&q=80",isNew:true,active:true},
{id:5,title:"บันทึกของนักเดินทาง",author:"ธันวา",category:"แฟนตาซี",price:329,stock:8,image:"https://images.unsplash.com/photo-1513001900722-370f803f498d?auto=format&fit=crop&w=600&q=80",isNew:false,active:true},
{id:6,title:"รักแรกในวันฝนพรำ",author:"ลลิน",category:"วัยรุ่น",price:239,stock:22,image:"https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=600&q=80",isNew:true,active:true},
{id:7,title:"เงื่อนงำใต้แสงจันทร์",author:"ภาคิน",category:"สืบสวน",price:299,stock:9,image:"https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80",isNew:false,active:true},
{id:8,title:"จดหมายถึงวันพรุ่งนี้",author:"อัญญา",category:"โรแมนติก",price:279,stock:11,image:"https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=600&q=80",isNew:false,active:true}
];
const starterPromos=[{id:101,title:"ลดราคาพิเศษสำหรับนักอ่าน",description:"ราคาพิเศษสำหรับหนังสือคืนที่ดาวเต็มฟ้า",productId:1,salePrice:229,endDate:"2027-12-31",active:true},{id:102,title:"แฟนตาซีราคาพิเศษ",description:"พบกับโลกจินตนาการในราคาที่คุ้มค่า",productId:2,salePrice:299,endDate:"2027-12-31",active:true}];
function read(key,fallback){try{const v=JSON.parse(localStorage.getItem(key));return v===null?fallback:v}catch{return fallback}}
function write(key,value){localStorage.setItem(key,JSON.stringify(value))}
function seed(){if(!localStorage.getItem(KEY.products))write(KEY.products,starterProducts);if(!localStorage.getItem(KEY.promos))write(KEY.promos,starterPromos);if(!localStorage.getItem(KEY.users))write(KEY.users,[{id:1,name:"ผู้ดูแลระบบ",email:"admin@csbooks.com",password:"admin123",role:"admin"}]);}
seed();
const products=()=>read(KEY.products,[]),saveProducts=v=>write(KEY.products,v);
const promos=()=>read(KEY.promos,[]),savePromos=v=>write(KEY.promos,v);
const cart=()=>read(KEY.cart,[]),saveCart=v=>write(KEY.cart,v);
const users=()=>read(KEY.users,[]),saveUsers=v=>write(KEY.users,v);
const orders=()=>read(KEY.orders,[]),saveOrders=v=>write(KEY.orders,v);
const current=()=>read(KEY.current,null),setCurrent=v=>write(KEY.current,v),logout=()=>localStorage.removeItem(KEY.current);
function activePromo(productId){return promos().find(p=>p.productId===productId&&p.active&&(!p.endDate||p.endDate>=new Date().toISOString().slice(0,10)))}
function priceOf(product){const p=activePromo(product.id);return p?Number(p.salePrice):Number(product.price)}
function cartCount(){return cart().reduce((s,i)=>s+i.quantity,0)}
function addToCart(id){const p=products().find(x=>x.id===id&&x.active);if(!p)return alert("ไม่พบหนังสือเล่มนี้");let c=cart(),item=c.find(x=>x.id===id);if(item)item.quantity++;else c.push({id,quantity:1});saveCart(c);updateCartBadges();alert("เพิ่มหนังสือลงตะกร้าแล้ว")}
function updateCartBadges(){document.querySelectorAll("#cart-count").forEach(x=>x.textContent=cartCount());}
function productCard(p){const sale=activePromo(p.id),price=priceOf(p);return `<article class="product-card"><div class="product-image"><img src="${p.image||'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80'}" alt="ปกหนังสือ ${p.title}">${sale?'<span class="sale-tag">PROMOTION</span>':''}</div><div class="product-info"><span class="product-category">${p.category}</span><h3>${p.title}</h3><p class="product-author">ผู้แต่ง: ${p.author}</p><div class="product-bottom"><span><b class="price">฿${price}</b>${sale?`<small class="old-price">฿${p.price}</small>`:''}</span><button class="add-cart" data-add="${p.id}">+ ใส่ตะกร้า</button></div></div></article>`}
document.addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(b)addToCart(Number(b.dataset.add))});
document.addEventListener("DOMContentLoaded",()=>{updateCartBadges();const a=document.getElementById("account-link"),u=current();if(a&&u){a.textContent=u.name||"บัญชีของฉัน";a.href=u.role==="admin"?"admin.html":"index.html";}});
return {KEY,products,saveProducts,promos,savePromos,cart,saveCart,users,saveUsers,orders,saveOrders,current,setCurrent,logout,activePromo,priceOf,cartCount,addToCart,updateCartBadges,productCard};
})();